package com.themeloader

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.File
import java.util.UUID

class CreateActivity : ComponentActivity() {
    private val draft by lazy { File(filesDir, "draft") }
    private lateinit var etName: EditText
    private lateinit var etAuthor: EditText
    private lateinit var etDesc: EditText
    private lateinit var logView: TextView
    private var pendingIcon: ResolveInfo? = null

    private val pickWall = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) bg { setWallpaper(uri) }
    }
    private val pickIcon = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val ri = pendingIcon
        if (uri != null && ri != null) bg { setIcon(ri, uri) }
    }
    private val exportZip = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val meta = meta()
            bg {
                saveManifest(meta)
                contentResolver.openOutputStream(uri)!!.use { ThemeOps.zipDir(draft, it) }
                log("Zip exportado")
            }
        }
    }

    private fun meta() = Triple(etName.text.toString(), etAuthor.text.toString(), etDesc.text.toString())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        fun field(hint: String): EditText {
            val e = EditText(this).apply { this.hint = hint; inputType = InputType.TYPE_CLASS_TEXT }
            col.addView(e); return e
        }
        fun button(t: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }
        etName = field("Nombre del tema")
        etAuthor = field("Autor")
        etDesc = field("Descripción")
        button("Usar el tema activo como base") {
            bg { ThemeOps.exportCurrent(this, draft, ::log); newIdentity(); runOnUiThread { loadFields() } }
        }
        button("Elegir fondo de pantalla") { pickWall.launch("image/*") }
        button("Cambiar icono de una app") { chooseApp() }
        button("Exportar .zip") {
            val n = etName.text.toString().ifBlank { "tema" }
            exportZip.launch("$n.zip")
        }
        button("Guardar y aplicar ahora") {
            val meta = meta()
            bg { saveManifest(meta); ThemeOps.install(this, draft, ::log) }
        }
        logView = TextView(this).apply { setTextIsSelectable(true); setPadding(0, 24, 0, 0) }
        col.addView(logView)
        setContentView(ScrollView(this).apply { addView(col) })
        ensureDraft()
        loadFields()
    }

    private fun log(m: String) { runOnUiThread { logView.append(m + "\n") } }

    private fun bg(block: () -> Unit) {
        Thread {
            try { block() } catch (e: Throwable) { log("Error: ${e.message}") }
        }.start()
    }

    private fun ensureDraft() {
        for (d in listOf("icons", "wallpapers", "preview", "app")) File(draft, d).mkdirs()
    }

    private fun loadFields() {
        val mf = File(draft, "manifest.json")
        if (!mf.exists()) return
        val m = JSONObject(mf.readText())
        etName.setText(m.optString("name")); etAuthor.setText(m.optString("author")); etDesc.setText(m.optString("description"))
    }

    private fun newIdentity() {
        ensureDraft()
        val mf = File(draft, "manifest.json")
        val m = if (mf.exists()) JSONObject(mf.readText()) else JSONObject()
        m.put("id", UUID.randomUUID().toString())
        m.put("name", m.optString("name", "Tema") + " (copia)")
        mf.writeText(m.toString(2))
    }

    private fun saveManifest(meta: Triple<String, String, String>) {
        ensureDraft()
        val mf = File(draft, "manifest.json")
        val m = if (mf.exists()) JSONObject(mf.readText()) else JSONObject()
        if (m.optString("id").isBlank()) m.put("id", UUID.randomUUID().toString())
        m.put("name", meta.first.ifBlank { "Tema" })
        m.put("author", meta.second.ifBlank { "Unknown" })
        m.put("description", meta.third)
        m.put("type", 0); m.put("version", m.optInt("version", 15))
        m.put("app_resource_dir", "app"); m.put("os_version", "all")
        mf.writeText(m.toString(2))
    }

    private fun decode(uri: Uri, maxDim: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var s = 1
        while (bounds.outWidth / s > maxDim || bounds.outHeight / s > maxDim) s *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = s }
        return contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw RuntimeException("No se pudo leer la imagen")
    }

    private fun setWallpaper(uri: Uri) {
        ensureDraft()
        val dir = File(draft, "wallpapers")
        val target = dir.listFiles()?.firstOrNull { it.isFile } ?: File(dir, "wallpaper.jpg")
        val bmp = decode(uri, 3000)
        val png = target.extension.equals("png", true)
        target.outputStream().use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, 95, it) }
        log("Fondo guardado como wallpapers/${target.name}")
    }

    private fun chooseApp() {
        val pm = packageManager
        val list = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).sortedBy { it.loadLabel(pm).toString().lowercase() }
        AlertDialog.Builder(this)
            .setTitle("Elige la app")
            .setItems(list.map { "${it.loadLabel(pm)}  (${it.activityInfo.packageName})" }.toTypedArray()) { _, i ->
                pendingIcon = list[i]
                pickIcon.launch("image/*")
            }.show()
    }

    private fun setIcon(ri: ResolveInfo, uri: Uri) {
        ensureDraft()
        val bmp = Bitmap.createScaledBitmap(decode(uri, 1024), 162, 162, true)
        val dir = File(draft, "icons")
        for (n in listOf(ri.activityInfo.packageName, ri.activityInfo.name).distinct()) {
            File(dir, "$n.png").outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        }
        log("Icono guardado: ${ri.activityInfo.packageName}")
    }
}

package com.themeloader

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object ThemeOps {
    const val BASE = "/data/system/resource-override"
    const val BK = "/data/adb/themeloader_backup"
    val DEFAULT_PKGS = listOf(
        "com.transsion.itel.launcher", "com.transsion.keyguardclock", "com.transsion.keyguardtheme",
        "com.transsion.launcher3", "com.transsion.XOSLauncher", "com.transsion.hilauncher", "com.transsion.aod"
    )
    private val UUID_RE = Regex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}")

    fun unzipTo(input: InputStream, dest: File) {
        dest.deleteRecursively(); dest.mkdirs()
        val root = dest.canonicalPath + File.separator
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val f = File(dest, e.name)
                require(f.canonicalPath.startsWith(root)) { "Ruta inválida en el zip" }
                if (e.isDirectory) f.mkdirs() else {
                    f.parentFile?.mkdirs()
                    f.outputStream().use { z.copyTo(it) }
                }
                e = z.nextEntry
            }
        }
        if (!File(dest, "manifest.json").exists()) {
            val sub = dest.listFiles()?.firstOrNull { it.isDirectory && File(it, "manifest.json").exists() }
            if (sub != null) {
                val tmp = File(dest.parentFile, dest.name + "_tmp")
                tmp.deleteRecursively()
                sub.renameTo(tmp); dest.deleteRecursively(); tmp.renameTo(dest)
            }
        }
    }

    fun zipDir(dir: File, out: OutputStream) {
        ZipOutputStream(out).use { z ->
            dir.walkTopDown().filter { it != dir }.forEach { f ->
                val rel = f.relativeTo(dir).path.replace('\\', '/')
                if (f.isDirectory) { z.putNextEntry(ZipEntry("$rel/")); z.closeEntry() }
                else { z.putNextEntry(ZipEntry(rel)); f.inputStream().use { it.copyTo(z) }; z.closeEntry() }
            }
        }
    }

    fun normalize(stage: File): JSONObject {
        val mf = File(stage, "manifest.json")
        require(mf.exists()) { "El tema no contiene manifest.json" }
        val m = JSONObject(mf.readText())
        if (m.optString("id").isBlank()) m.put("id", UUID.randomUUID().toString())
        m.put("type", m.optInt("type", 0))
        m.put("version", m.optInt("version", 15))
        if (!m.has("author")) m.put("author", "Unknown")
        if (!m.has("name")) m.put("name", "Theme")
        if (!m.has("description")) m.put("description", "")
        m.put("app_resource_dir", "app")
        m.put("os_version", "all")
        File(stage, "app").mkdirs()
        mf.writeText(m.toString(2))
        return m
    }

    fun install(ctx: Context, stage: File, log: (String) -> Unit) {
        val m = normalize(stage)
        val id = m.getString("id")
        val ver = m.getInt("version").toString()
        val dirName = "$id@$ver"
        val appDir = File(stage, "app")
        val pkgs = appDir.listFiles()?.filter { it.isDirectory }?.map { it.name }.orEmpty().ifEmpty { DEFAULT_PKGS }
        val gen = File(ctx.cacheDir, "gen").apply { deleteRecursively(); mkdirs() }
        File(gen, "global_config.xml").writeBytes(Abx.globalConfig(dirName, pkgs))
        val now = System.currentTimeMillis()
        val desc = m.optString("description")
        File(gen, "theme_manifest.xml").writeBytes(Abx.themeManifest(listOf(
            "id" to id, "user" to "0", "author" to m.optString("author"), "version" to ver, "type" to "0",
            "app" to "app", "des" to desc, "source" to "com.transsion.theme", "timestamp" to now.toString(),
            "enabled_order" to (now / 1000).toString(), "type_flags" to "594", "description" to desc,
            "name" to m.optString("name"), "app_resource_dir" to "app", "os_version" to "all"
        )))
        val B = BASE
        val lines = listOf(
            "mkdir -p $BK $B",
            "for f in global_config.xml theme_manifest.xml; do if [ ! -f $BK/\$f.orig ] && [ ! -f $BK/\$f.none ]; then if [ -f $B/\$f ]; then cp -p $B/\$f $BK/\$f.orig; else touch $BK/\$f.none; fi; fi; done",
            "rm -rf $B/$dirName",
            "cp -r ${stage.absolutePath} $B/$dirName",
            "rm -rf $B/mapping-cache/* || true",
            "cp ${gen.absolutePath}/global_config.xml $B/global_config.xml",
            "cp ${gen.absolutePath}/theme_manifest.xml $B/theme_manifest.xml",
            "chown -R system:system $B/$dirName $B/global_config.xml $B/theme_manifest.xml",
            "chmod -R u+rwX,g+rX $B/$dirName",
            "chmod 660 $B/global_config.xml $B/theme_manifest.xml",
            "restorecon -R $B",
            "test -f $B/$dirName/manifest.json"
        )
        val r = Root.run(lines.joinToString("\n"))
        if (r.code != 0) throw RuntimeException("Falló la copia (${r.code}): ${r.out}")
        log("Tema \"${m.optString("name")}\" copiado a $dirName")
        log("Ahora pulsa \"Reiniciar launcher y SystemUI\". Si no cambia, usa el reinicio suave.")
    }

    fun restore(log: (String) -> Unit) {
        val B = BASE
        val lines = listOf(
            "for f in global_config.xml theme_manifest.xml; do if [ -f $BK/\$f.orig ]; then cp $BK/\$f.orig $B/\$f; chown system:system $B/\$f; chmod 660 $B/\$f; elif [ -f $BK/\$f.none ]; then rm -f $B/\$f; fi; done",
            "restorecon -R $B",
            "true"
        )
        Root.run(lines.joinToString("\n"))
        log("Configuración original restaurada. Reinicia launcher/SystemUI.")
    }

    fun refresh(log: (String) -> Unit) {
        val s = DEFAULT_PKGS.joinToString("\n") { "am force-stop $it" }
        val r = Root.run("$s\nkillall com.android.systemui 2>/dev/null || pkill -f com.android.systemui || true")
        log("Launcher y SystemUI reiniciados. ${r.out}")
    }

    fun softReboot(log: (String) -> Unit) {
        log("Reinicio suave…")
        Root.run("setprop ctl.restart zygote")
    }

    /** Copia el tema activo (el que dice theme_manifest.xml) a [dest] para usarlo como base. */
    fun exportCurrent(ctx: Context, dest: File, log: (String) -> Unit) {
        val id = UUID_RE.find(Root.run("cat $BASE/theme_manifest.xml").out)?.value
            ?: throw RuntimeException("No hay tema activo en $BASE")
        val tmp = File(ctx.cacheDir, "cur").apply { deleteRecursively(); mkdirs() }
        val uid = android.os.Process.myUid()
        val r = Root.run(
            "for d in $BASE/$id@*; do cp -r \"\$d\" ${tmp.absolutePath}/theme; done\n" +
                "chown -R $uid:$uid ${tmp.absolutePath}\nchmod -R u+rwX ${tmp.absolutePath}\ntest -d ${tmp.absolutePath}/theme"
        )
        if (r.code != 0) throw RuntimeException("No se pudo copiar el tema activo: ${r.out}")
        dest.deleteRecursively()
        File(tmp, "theme").copyRecursively(dest, true)
        log("Tema activo copiado como base")
    }

    /** Vuelca el estado del sistema a /sdcard/Download/themeloader_diag.txt para depurar. */
    fun diag(log: (String) -> Unit) {
        val B = BASE
        val out = "/sdcard/Download/themeloader_diag.txt"
        val s = """
{
echo "== ls"; ls -laZ $B; ls -laZ $B/*@*
echo "== global_config (strings)"; cat $B/global_config.xml | tr -c '[:print:]' ' '
echo; echo "== theme_manifest (strings)"; cat $B/theme_manifest.xml | tr -c '[:print:]' ' '
echo; echo "== servicios"; dumpsys -l | grep -iE 'theme|resource|override|overlay'
echo "== cmd"; cmd -l | grep -iE 'theme|resource|override'
echo "== props"; getprop | grep -iE 'transsion|ro.os|ro.tr|build.version.release|product.brand|display.id'
echo "== logcat"; logcat -d -v time | grep -iE 'override|ThemeService|GlobalTheme|resource-override|transsion.*theme' | tail -200
echo "== backups"; ls -laZ $BK
} > $out 2>&1
chmod 666 $out
"""
        val r = Root.run(s)
        log("Diagnóstico guardado en Download/themeloader_diag.txt (código ${r.code}). Súbelo al chat.")
    }
}

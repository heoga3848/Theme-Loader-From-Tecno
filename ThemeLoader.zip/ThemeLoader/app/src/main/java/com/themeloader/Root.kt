package com.themeloader

object Root {
    data class Result(val code: Int, val out: String)

    fun run(script: String): Result {
        val p = ProcessBuilder("su").redirectErrorStream(true).start()
        p.outputStream.bufferedWriter().use { it.write(script + "\nexit \$?\n") }
        val out = p.inputStream.bufferedReader().readText()
        return Result(p.waitFor(), out.trim())
    }

    fun available(): Boolean = try { run("id").out.contains("uid=0") } catch (e: Exception) { false }
}

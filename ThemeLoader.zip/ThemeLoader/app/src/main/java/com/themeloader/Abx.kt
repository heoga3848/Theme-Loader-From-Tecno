package com.themeloader

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream

/** Escritor del XML binario (ABX) de Android. Verificado byte a byte contra global_config.xml y theme_manifest.xml reales. */
class Abx(private val doc: Boolean) {
    private val buf = ByteArrayOutputStream()
    private val out = DataOutputStream(buf)
    private val pool = HashMap<String, Int>()
    private val stack = ArrayDeque<String>()

    init {
        out.write(byteArrayOf(0x41, 0x42, 0x58, 0x00))
        if (doc) out.write(0x10)
    }

    private fun intern(s: String) {
        val i = pool[s]
        if (i != null) out.writeShort(i) else {
            pool[s] = pool.size
            out.writeShort(0xffff)
            out.writeUTF(s)
        }
    }

    fun start(n: String) { out.write(0x32); intern(n); stack.addLast(n) }
    fun attr(n: String, v: String) { out.write(0x2f); intern(n); out.writeUTF(v) }
    fun end() { val n = stack.removeLast(); out.write(0x33); intern(n) }
    fun bytes(): ByteArray { if (doc) out.write(0x11); out.flush(); return buf.toByteArray() }

    companion object {
        fun globalConfig(setName: String, pkgs: List<String>): ByteArray {
            val w = Abx(true)
            w.start("OverrideConfig")
            w.start("version"); w.attr("value", "1.0"); w.end()
            w.start("current-user"); w.attr("value", "0"); w.end()
            w.start("set")
            w.attr("name", setName); w.attr("priority", "5"); w.attr("user", "0")
            w.attr("dir", "app"); w.attr("enable", "0")
            for (p in pkgs) { w.start("package"); w.attr("value", p); w.end() }
            w.end()
            w.start("forbidden-set-list"); w.end()
            w.start("forbidden-package-list"); w.end()
            w.end()
            return w.bytes()
        }

        fun themeManifest(attrs: List<Pair<String, String>>): ByteArray {
            val w = Abx(false)
            w.start("manifest")
            for ((k, v) in attrs) w.attr(k, v)
            w.end()
            return w.bytes()
        }
    }
}

package com.themeloader

import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var logView: TextView

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadZip(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        fun button(t: String, f: () -> Unit) {
            col.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        }
        button("Cargar tema desde .zip y aplicar") { pickZip.launch(arrayOf("*/*")) }
        button("Crear tema") { startActivity(Intent(this, CreateActivity::class.java)) }
        button("Reiniciar launcher y SystemUI") { bg { ThemeOps.refresh(::log) } }
        button("Reinicio suave (zygote)") {
            AlertDialog.Builder(this)
                .setMessage("Se reiniciará la interfaz del sistema. ¿Continuar?")
                .setPositiveButton("Sí") { _, _ -> bg { ThemeOps.softReboot(::log) } }
                .setNegativeButton("No", null).show()
        }
        button("Restaurar configuración original") { bg { ThemeOps.restore(::log) } }
        logView = TextView(this).apply { setTextIsSelectable(true); setPadding(0, 24, 0, 0) }
        col.addView(logView)
        setContentView(ScrollView(this).apply { addView(col) })
        bg { log(if (Root.available()) "Root OK" else "Sin acceso root: concede permiso a esta app en tu gestor (KernelSU/Magisk).") }
    }

    private fun log(m: String) { runOnUiThread { logView.append(m + "\n") } }

    private fun bg(block: () -> Unit) {
        Thread {
            try { block() } catch (e: Throwable) { log("Error: ${e.message}") }
        }.start()
    }

    private fun loadZip(uri: Uri) = bg {
        log("Leyendo zip…")
        val stage = File(cacheDir, "stage")
        contentResolver.openInputStream(uri)!!.use { ThemeOps.unzipTo(it, stage) }
        ThemeOps.install(this, stage, ::log)
    }
}

# Theme Loader (Transsion)
App root que carga/crea temas en /data/system/resource-override, sin permisos de Android ni internet.

- Cargar .zip: el zip debe tener manifest.json, app/, icons/, preview/, wallpapers/ (como tu tema Pink Daydream).
- Crear: puedes basarte en el tema activo, cambiar nombre, fondo e iconos y exportar .zip o aplicar.
- Aplicar: copia la carpeta <id>@<version>, genera global_config.xml y theme_manifest.xml (ABX) y hace copia de seguridad en /data/adb/themeloader_backup.
- Restaurar: devuelve los dos XML originales.
Compilar: sube todo a GitHub; el workflow genera el APK en Actions > Artifacts.
